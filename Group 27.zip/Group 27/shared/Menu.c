/**
 * @file menu.c
 * Space-themed menu with stars, scanlines, 16-color palette.
 * Uses LCD.h index colours (0-15).
 */

#include "menu.h"
#include "LCD.h"
#include "Joystick.h"
#include "InputHandler.h"
#include "Buzzer.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/* Colour indexes from default palette (LCD.h) */
#define COLOR_BLACK     0
#define COLOR_WHITE     1
#define COLOR_RED       2
#define COLOR_GREEN     3
#define COLOR_BLUE      4
#define COLOR_ORANGE    5
#define COLOR_YELLOW    6
#define COLOR_PINK      7
#define COLOR_PURPLE    8
#define COLOR_NAVY      9
#define COLOR_GOLD      10
#define COLOR_VIOLET    11
#define COLOR_BROWN     12
#define COLOR_GREY      13
#define COLOR_CYAN      14
#define COLOR_MAGENTA   15

/* shortcuts for readability */
#define C_BLACK     COLOR_BLACK
#define C_WHITE     COLOR_WHITE
#define C_RED       COLOR_RED
#define C_GREEN     COLOR_GREEN
#define C_BLUE      COLOR_BLUE
#define C_CYAN      COLOR_CYAN
#define C_MAGENTA   COLOR_MAGENTA
#define C_YELLOW    COLOR_YELLOW
#define C_ORANGE    COLOR_ORANGE
#define C_PINK      COLOR_PINK
#define C_LIME      COLOR_GREEN   /* reuse green */
#define C_TEAL      COLOR_CYAN
#define C_LAVENDER  COLOR_VIOLET
#define C_GREY      COLOR_GREY
#define C_GOLD      COLOR_GOLD
#define C_INDIGO    COLOR_NAVY

/* externs from other modules */
extern Joystick_cfg_t joystick_cfg;
extern Joystick_t     joystick_data;
extern ST7789V2_cfg_t cfg0;
extern Buzzer_cfg_t   buzzer_cfg;

/* quick sfx helper */
static inline void menu_sfx(uint32_t freq, uint32_t ms) {
    if (freq == 0 || ms == 0) { buzzer_off(&buzzer_cfg); return; }
    buzzer_tone(&buzzer_cfg, freq, 50);
    HAL_Delay(ms);
    buzzer_off(&buzzer_cfg);
}

/* ========== starfield ========== */
#define MAX_STARS 80
typedef struct {
    uint8_t x, y;
    uint8_t brightness;   // 1..3
    uint8_t phase;
} Star_t;

static Star_t stars[MAX_STARS];
static uint16_t anim_counter = 0;
static uint8_t  selection_changed = 1;

static void init_stars(void) {
    for (int i = 0; i < MAX_STARS; i++) {
        stars[i].x = rand() % 240;
        stars[i].y = rand() % 280;
        stars[i].brightness = rand() % 3 + 1;
        stars[i].phase = rand() % 8;
    }
}

static void update_stars(void) {
    for (int i = 0; i < MAX_STARS; i++) {
        stars[i].phase = (stars[i].phase + 1) % 8;
        if (stars[i].phase == 0)
            stars[i].brightness = (stars[i].brightness % 3) + 1;

        // occasional drift
        if (rand() % 120 == 0) stars[i].x = (stars[i].x + 1) % 240;
        if (rand() % 150 == 0) stars[i].y = (stars[i].y + 1) % 280;
    }
}

static void draw_stars(void) {
    for (int i = 0; i < MAX_STARS; i++) {
        uint8_t col;
        switch (stars[i].brightness) {
            case 1:  col = C_GREY; break;
            case 2:  col = C_WHITE; break;
            default: col = C_CYAN; break;
        }
        // twinkle
        if ((anim_counter + stars[i].phase) % 6 < 2) col = C_YELLOW;
        LCD_Draw_Rect(stars[i].x, stars[i].y, 1, 1, col, 1);
    }
}

/* ========== eye candy ========== */
static void draw_scanline_aura(void) {
    uint8_t phase = (anim_counter / 4) % 32;
    uint8_t colors[] = {C_CYAN, C_MAGENTA, C_GOLD, C_ORANGE};
    for (int i = 0; i < 4; i++) {
        uint8_t y = 30 + (phase + i * 8) % 220;
        LCD_Draw_Rect(0, y, 240, 1, colors[i % 4], 1);
        LCD_Draw_Rect(0, y + 2, 240, 1, colors[(i+1)%4], 1);
    }
}

static void draw_corner_vortex(void) {
    uint8_t t = (anim_counter / 2) % 20;
    uint8_t colors[] = {C_RED, C_ORANGE, C_YELLOW, C_GREEN, C_CYAN};
    for (int i = 0; i < 6; i++) {
        uint8_t offset = (t + i * 3) % 20;
        LCD_Draw_Rect(10 + offset, 250 - offset/2, 2, 2, colors[i%5], 1);
        LCD_Draw_Rect(230 - offset, 250 - offset/2, 2, 2, colors[(i+2)%5], 1);
    }
}

/* ========== UI drawing ========== */
static void draw_title(void) {
    const char* title1 = "COSMIC";
    const char* title2 = "ARENA";
    const char* subtitle = ">>  FIREWALL  DEFENDER  <<";

    // shadow effect
    LCD_printString(title1, 58, 38, C_INDIGO, 2);
    LCD_printString(title2, 74, 68, C_INDIGO, 2);
    LCD_printString(title1, 56, 36, C_GOLD, 2);
    LCD_printString(title2, 72, 66, C_GOLD, 2);

    // neon subtitle
    for (int i = 0; i < 3; i++)
        LCD_printString(subtitle, 34 + i*2, 98 + i, C_CYAN, 1);
    LCD_printString(subtitle, 36, 100, C_WHITE, 1);

    // decorative bars
    for (int i = 0; i < 5; i++) {
        uint8_t col = (i % 2) ? C_TEAL : C_MAGENTA;
        LCD_Draw_Rect(30 + i*40, 116, 28, 2, col, 1);
    }
}

static void draw_menu_option(uint8_t idx, const char* text, uint8_t is_selected) {
    uint16_t y_base = 150 + idx * 36;
    uint16_t x_text = 60;

    if (is_selected) {
        uint8_t pulse = (anim_counter % 16 < 8) ? C_CYAN : C_WHITE;
        LCD_Draw_Rect(30, y_base - 6, 180, 28, C_BLACK, 1);
        LCD_Draw_Rect(32, y_base - 4, 176, 24, pulse, 0);
        LCD_Draw_Rect(34, y_base - 2, 172, 20, C_INDIGO, 0);
        LCD_printString(">", 38, y_base + 2, C_GOLD, 1);
        LCD_printString("<", 192, y_base + 2, C_GOLD, 1);
    } else {
        LCD_Draw_Rect(30, y_base - 6, 180, 28, C_BLACK, 1);
    }

    // coloured dot
    uint8_t dot_color[] = {C_RED, C_LIME, C_ORANGE};
    LCD_Draw_Rect(48, y_base + 4, 6, 6, dot_color[idx], 1);
    LCD_Draw_Rect(50, y_base + 6, 2, 2, C_BLACK, 1);

    // text with subtle outline
    for (int off = -1; off <= 1; off++) {
        if (off == 0)
            LCD_printString(text, x_text, y_base + 2, is_selected ? C_YELLOW : C_WHITE, 1);
        else
            LCD_printString(text, x_text + off, y_base + 2 + (off&1), C_GREY, 1);
    }

    // right side leds
    if (is_selected) {
        for (int i = 0; i < 3; i++) {
            uint8_t col = (anim_counter + i*5) % 2 ? C_RED : C_BLUE;
            LCD_Draw_Rect(214 + i*4, y_base + 8, 2, 6, col, 1);
        }
    }
}

static void draw_footer(void) {
    const char* help = " [ JOY UP/DOWN ]  ( BTN3 )  LAUNCH MISSION";
    LCD_printString(help, 24, 252, C_GREY, 1);
    // moving energy bar
    uint8_t w = (anim_counter % 80) + 10;
    LCD_Draw_Rect(40, 268, w, 3, C_GREEN, 1);
    LCD_Draw_Rect(40, 272, 160, 1, C_BLUE, 0);
}

/* ========== menu logic ========== */
static MenuState current_selection_state(MenuSystem* menu) {
    switch (menu->selected_option) {
        case 0: return MENU_STATE_GAME_1;
        case 1: return MENU_STATE_GAME_2;
        case 2: return MENU_STATE_GAME_3;
        default: return MENU_STATE_GAME_1;
    }
}

void Menu_Init(MenuSystem* menu) {
    if (menu) menu->selected_option = 0;
    init_stars();
    anim_counter = 0;
    menu_sfx(1800, 35);  // power-on beep
}

MenuState Menu_Run(MenuSystem* menu) {
    if (!menu) {
        static MenuSystem fallback;
        menu = &fallback;
        Menu_Init(menu);
    }

    uint8_t debounce = 0;

    while (1) {
        Input_Read();
        Joystick_Read(&joystick_cfg, &joystick_data);
        UserInput joy = Joystick_GetInput(&joystick_data);

        if (debounce == 0) {
            if (joy.direction == N || joy.direction == NW || joy.direction == NE) {
                if (menu->selected_option > 0) {
                    menu->selected_option--;
                    menu_sfx(2100, 15);
                    selection_changed = 1;
                }
                debounce = 8;
            } else if (joy.direction == S || joy.direction == SW || joy.direction == SE) {
                if (menu->selected_option < 2) {
                    menu->selected_option++;
                    menu_sfx(2100, 15);
                    selection_changed = 1;
                }
                debounce = 8;
            } else if (current_input.btn3_pressed) {
                menu_sfx(2800, 60);
                LCD_Fill_Buffer(C_BLACK);
                LCD_Refresh(&cfg0);
                return current_selection_state(menu);
            }
        }
        if (debounce > 0) debounce--;

        update_stars();
        anim_counter++;

        // redraw every 2 frames or when selection changed
        if (selection_changed || anim_counter % 2 == 0) {
            LCD_Fill_Buffer(C_BLACK);
            draw_stars();
            draw_scanline_aura();
            draw_corner_vortex();
            draw_title();

            const char* items[3] = {
                ">  FIREWALL  DEFENDER",
                ">  CAUTION  TRAP",
                ">  Submarine Rescue"
            };
            for (int i = 0; i < 3; i++)
                draw_menu_option(i, items[i], (i == menu->selected_option));

            draw_footer();
            LCD_Refresh(&cfg0);
            selection_changed = 0;
        }

        HAL_Delay(28);
    }
}